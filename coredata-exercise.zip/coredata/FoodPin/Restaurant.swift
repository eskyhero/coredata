//
//  Restaurant.swift
//  FoodPin
//
//  Created by xiaobo on 15/11/9.
//  Copyright © 2015年 xiaobo. All rights reserved.
//

import Foundation
import CoreData


class Restaurant: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
