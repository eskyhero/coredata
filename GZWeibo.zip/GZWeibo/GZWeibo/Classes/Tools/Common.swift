//
//  Common.swift
//  GZWeibo
//
//  Created by Apple on 15/9/22.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

// MARK: - 定义全局的通知
/// 切换根控制器通知
let WBSwitchRootViewControllerNotification = "WBSwitchRootViewControllerNotification"

// MARK: - 全局信息设置
/// 全局外观渲染颜色
let WBAppearanceColor = UIColor.orangeColor()