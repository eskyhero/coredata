//
//  UITextView+Emoticon.swift
//  01-表情键盘
//
//  Created by Apple on 15/10/7.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

extension UITextView {
        
    /// 返回 textView 中的完整表情字符串
    var emoticonText: String {
        
        let attrText = attributedText
        var strM = String()
        
        attrText.enumerateAttributesInRange(NSRange(location: 0, length: attrText.length), options: []) { (dict, range, _) -> Void in
            
            if let attachment = dict["NSAttachment"] as? EmoticonAttachment {
                strM += attachment.chs ?? ""
            } else {    // 文本
                
                let str = (attrText.string as NSString).substringWithRange(range)
                strM += str
            }
        }
        
        return strM
    }
    
    /// 插入表情
    func insertEmoticon(emoticon: Emoticon) {
        
        // 1. 是否空白表情
        if emoticon.isEmpty {
            return
        }
        
        // 2. 是否删除按钮
        if emoticon.isRemove {
            deleteBackward()
            
            return
        }
        
        // 3. emoji
        if let emoji = emoticon.emoji {
            replaceRange(selectedTextRange!, withText: emoji)
            
            return
        }
        
        // 4. 表情图片
        // 1> 创建图片的附件文本
        let imageText = EmoticonAttachment.emotionText(emoticon, font: font!)
        
        // 2> 获取 textView 中的富文本
        let attrString = NSMutableAttributedString(attributedString: attributedText)
        attrString.replaceCharactersInRange(selectedRange, withAttributedString: imageText)
        
        // 3> 更新 textView 富文本
        // 1) 替换之前，记录当前光标位置
        let range = selectedRange
        // 2) 替换文本
        attributedText = attrString
        // 3) 恢复光标位置 length 标示选中文本的长度
        selectedRange = NSRange(location: range.location + 1, length: 0)
        
        // 5. 主动调用代理方法 self 就是textView
        // textView是委托方->发生事件的时候，通知代理去工作！
        delegate?.textViewDidChange!(self)
    }
}
