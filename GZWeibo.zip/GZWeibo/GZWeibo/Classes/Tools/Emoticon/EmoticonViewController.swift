//
//  EmoticonViewController.swift
//  01-表情键盘
//
//  Created by Apple on 15/9/30.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

/// 可重用标示符号
private let EmoticonViewCellID = "EmoticonViewCellID"

class EmoticonViewController: UIViewController {

    /// 选中表情回调
    var selectEmoticonCallBack: (emoticon: Emoticon) -> ()
    
    // MARK: - 构造函数
    // 闭包和 block，如果当前函数不执行，就需要使用一个属性记录
    init(selectEmoticon: (emoticon: Emoticon) -> ()) {
        selectEmoticonCallBack = selectEmoticon
        
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - 监听方法
    @objc private func clickItem(item: UIBarButtonItem) {
        // 每个表情包都是按照 section 来进行分组
        let indexPath = NSIndexPath(forItem: 0, inSection: item.tag)
        
        collectionView.scrollToItemAtIndexPath(indexPath, atScrollPosition: .Left, animated: true)
    }
    
    // MARK: - 设置界面
    /**
        从 iOS 7.0 开始，就不要相信 viewDidLoad 中的大小
        默认的键盘视图大小是 216 高度
    
        viewDidLoad 通常做视图创建完成后的数据加载
    */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(white: 0.95, alpha: 1.0)
        
        setupUI()
    }

    /// 设置界面
    private func setupUI() {
        // 1. 添加控件
        view.addSubview(collectionView)
        view.addSubview(toolbar)
        
        // 2. 自动布局
        toolbar.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(view.snp_bottom)
            make.left.equalTo(view.snp_left)
            make.right.equalTo(view.snp_right)
            make.height.equalTo(44)
        }
        collectionView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(view.snp_top)
            make.bottom.equalTo(toolbar.snp_top)
            make.left.equalTo(view.snp_left)
            make.right.equalTo(view.snp_right)
        }
        
        // 3. 设置控件
        prepareToolBar()
        prepareCollectionView()
    }
    
    /// 设置 collectioView
    private func prepareCollectionView() {
        // 设置背景颜色 
        collectionView.backgroundColor = UIColor.whiteColor()
        
        // 注册可重用 cell
        collectionView.registerClass(EmoticonViewCell.self, forCellWithReuseIdentifier: EmoticonViewCellID)
        
        // 设置数据源
        collectionView.dataSource = self
        collectionView.delegate = self
    }
    
    /// 设置 toolbar
    private func prepareToolBar() {
        
        // 设置 tintColor
        toolbar.tintColor = UIColor.darkGrayColor()
        
        // 设置按钮...
        var items = [UIBarButtonItem]()
        
        // 开发中，绝大多数区分 toolBar 的 item 是通过 tag 区分的
        var index = 0
        for package in viewModel.packages {
            items.append(UIBarButtonItem(title: package.group_name_cn, style: .Plain, target: self, action: "clickItem:"))
            items.last?.tag = index++
            
            items.append(UIBarButtonItem(barButtonSystemItem: .FlexibleSpace, target: nil, action: nil))
        }
        items.removeLast()
        
        toolbar.items = items
    }
    
    // MARK: - 懒加载控件
    /// 视图模型
    private lazy var viewModel = EmoticonViewModel.sharedViewModel
    /// collectionView
    private lazy var collectionView = UICollectionView(frame: CGRectZero, collectionViewLayout: EmoticonLayout())
    /// 工具条
    private lazy var toolbar = UIToolbar()
    
    // MARK: - 表情布局类，类中类，EmoticonLayout 的类，只允许被当前的控制器使用
    private class EmoticonLayout: UICollectionViewFlowLayout {
        
        // collect ionView 第一次要布局的时候会调用
        // 可以直接访问 collectionView
        // collectionView 的大小已经确定
        // 等比例计算 itemSize，非常合适！
        private override func prepareLayout() {
            print(collectionView)
            
            let col: CGFloat = 7
            let row: CGFloat = 3
            
            let w = collectionView!.bounds.width / col
            // 如果在 iPhone 4/4s 上，如果使用 0.5 会只显示两排，原因浮点数的精度不够！
            let margin = (collectionView!.bounds.height - row * w) * 0.499
            
            itemSize = CGSize(width: w, height: w)
            minimumInteritemSpacing = 0
            minimumLineSpacing = 0
            
            sectionInset = UIEdgeInsets(top: margin, left: 0, bottom: margin, right: 0)
            // 如果是水平滚动，cell是从上向下布局
            // 如果是垂直滚动，cell是从左向右布局
            scrollDirection = .Horizontal
            
            // 设置 collectionView 的属性
            collectionView?.pagingEnabled = true
            collectionView?.showsHorizontalScrollIndicator = false
        }
    }
}

// MARK: - UICollectionViewDataSource
extension EmoticonViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    /// 分组数量 - 返回表情包的数量
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return viewModel.packages.count
    }
    
    // 每个分组中格子的数量 - 每个表情包中的表情数量
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.packages[section].emoticons.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(EmoticonViewCellID, forIndexPath: indexPath) as! EmoticonViewCell
        
        // 设置 cell 的表情模型
        cell.emoticon = viewModel.packages[indexPath.section].emoticons[indexPath.item]
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        
        let em = viewModel.packages[indexPath.section].emoticons[indexPath.item]
        
        selectEmoticonCallBack(emoticon: em)
        
        // 添加最近使用的表情
        // 最近的分组不参加排序
        if indexPath.section > 0 {
            viewModel.favorite(em)
        }
    }
}

// MARK: - 表情 Cell
private class EmoticonViewCell: UICollectionViewCell {
    
    /// 表情模型
    var emoticon: Emoticon? {
        didSet {

            // 设置按钮表情`图片`
            // 如果没有表情，会将图片设置为 nil
            emoticonButton.setImage(UIImage(contentsOfFile: emoticon!.imagePath), forState: UIControlState.Normal)
            // 设置 emoji - 😄 `字符串`
            // 如果没有 emoji，会将 title 设置为 nil
            emoticonButton.setTitle(emoticon?.emoji, forState: UIControlState.Normal)
            
            // 判断是否是删除按钮
            if emoticon!.isRemove {
                emoticonButton.setImage(UIImage(named: "compose_emotion_delete"), forState: UIControlState.Normal)
            }
        }
    }
    
    // MARK: - 构造函数 
    // frame 的大小已经根据 layout 计算完成
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        contentView.addSubview(emoticonButton)
        emoticonButton.backgroundColor = UIColor.whiteColor()
        emoticonButton.setTitleColor(UIColor.blackColor(), forState: .Normal)
        emoticonButton.frame = CGRectInset(bounds, 2, 2)
        
        // 设置表情符号字体 － 通常字体大小和高度近似
        emoticonButton.titleLabel?.font = UIFont.systemFontOfSize(32)
        
        // 取消按钮的用户交互
        emoticonButton.userInteractionEnabled = false
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - 懒加载控件
    private lazy var emoticonButton = UIButton()
}
