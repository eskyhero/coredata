//
//  Emoticon.swift
//  01-表情键盘
//
//  Created by Apple on 15/9/30.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

/// 表情模型
class Emoticon: NSObject {
    /// 表情文字 － 网络传输使用
    var chs: String?
    
    /// 表情图片名称，只有图片的文件名，不包含路径
    var png: String?
    
    /// 表情图片的完整路径
    var imagePath: String {
        
        // StringByAppendPathComponent 方法，在 Swift 2.0 中，改为了 NSString 的方法
//        ((NSBundle.mainBundle().bundlePath as NSString).stringByAppendingPathComponent("Emoticons.bundle") as NSString).stringByAppendingPathComponent(png!)
        
        // 判断是否有图像，如果有，拼接完整路径
        if png != nil {
            return NSBundle.mainBundle().bundlePath + "/Emoticons.bundle/" + png!
        } else {
            return ""
        }
    }
    
    /// emoji编码字符串
    var code: String? {
        didSet {
            emoji = code?.emoji()
        }
    }
    /// emoji 的字符串
    var emoji: String?
    /// 删除按钮标记
    var isRemove = false
    /// 空表情
    var isEmpty = false
    /// 使用次数
    var times = 0
    
    // MARK: - 构造函数
    init(isRemove: Bool) {
        self.isRemove = isRemove
    }
    
    init(isEmpty: Bool) {
        self.isEmpty = isEmpty
    }
    
    init(dict: [String: String]) {
        super.init()
        
        setValuesForKeysWithDictionary(dict)
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
    
    override var description: String {
        let keys = ["chs", "png", "code", "emoji", "isRemove", "isEmpty", "times"]
        
        return dictionaryWithValuesForKeys(keys).description
    }
}
