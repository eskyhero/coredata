//
//  String+Emoji.swift
//  02-emoji
//
//  Created by Apple on 15/9/30.
//  Copyright © 2015年 itcast. All rights reserved.
//

import Foundation

// OC 中没有 String，只有 NSString
extension String {
    
    func emoji() -> String {
        // 1. 二进制数据
        let scanner = NSScanner(string: self)
        var value: UInt32 = 0
        scanner.scanHexInt(&value)
        
        // 2. unicode 字符串
        return String(Character(UnicodeScalar(value)))
    }
}