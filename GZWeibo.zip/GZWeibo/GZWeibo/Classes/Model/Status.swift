//
//  Status.swift
//  GZWeibo
//
//  Created by Apple on 15/9/25.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

/// 微博模型
class Status: NSObject {
    
    /// 微博ID
    var id: Int = 0
    /// 微博创建时间
    var created_at: String?
    /// 微博信息内容
    var text: String?
    /// 微博来源
    var source: String? {
        didSet {
            // 给 source 设置完成内容之后，马上用正则过滤文本，并且保存
            // 提示：在 didSet 内部设置，不会造成 didSet 重复调用
            source = source?.href()?.text
        }
    }
    /// 用户模型
    var user: User?
    /// 被转发的原微博信息字段
    var retweeted_status: Status?
    /// 微博配图数组
    var pic_urls: [[String: String]]?
    
    init(dict: [String: AnyObject]) {
        super.init()
        
        // 默认情况下，KVC 会把自定义对象，直接设置成 字典
        setValuesForKeysWithDictionary(dict)
    }
    
    override func setValue(value: AnyObject?, forKey key: String) {
        // 1. 判断 key 是否等于 user － 将自定义对象，单独处理
        if key == "user" {
            user = User(dict: value as! [String: AnyObject])
            
            // 注意：如果不 return，会继续调用 KVC 的默认方法，user又回再次被设置为字典
            return
        }
        
        // 2. 判断 key 是否等于 retweeted_status
        if key == "retweeted_status" {
            retweeted_status = Status(dict: value as! [String: AnyObject])
            
            return
        }
        
        super.setValue(value, forKey: key)
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {}
    
    override var description: String {
        let keys = ["id", "created_at", "text", "source", "user", "pic_urls", "retweeted_status"]
        
        return dictionaryWithValuesForKeys(keys).description
    }
}
