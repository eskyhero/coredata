//
//  UserAccount.swift
//  GZWeibo
//
//  Created by Apple on 15/9/22.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

/// 用户账户模型
/// - see: [http://open.weibo.com/wiki/OAuth2/access_token](http://open.weibo.com/wiki/OAuth2/access_token)
class UserAccount: NSObject, NSCoding {
    /// 用于调用access_token，接口获取授权后的access token
    /// token不安全，适用 token 的方式，只能访问`有限`的资源！
    var access_token: String?
    /// access_token的生命周期，单位是秒数。NSTimeInterval -> Double
    /// 为了保护用户的安全，token 提供了有效期
    /// 注册用户 - 五年
    /// `普通`用户 - 三天
    var expires_in: NSTimeInterval = 0 {
        didSet {
            // 计算并且设置过期日期
            expiresDate = NSDate(timeIntervalSinceNow: expires_in)
        }
    }
    /// 过期日期
    var expiresDate: NSDate?
    
    /// 当前授权用户的UID。
    var uid: String?
    
    /// 用户昵称
    var screen_name: String?
    /// 用户头像地址（大图），180×180像素
    var avatar_large: String?
    
    init(dict: [String: AnyObject]) {
        super.init()
        
        setValuesForKeysWithDictionary(dict)
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) { }
    
    /// 模型描述信息
    /// 提示：类似于 java 中 toString()，很多公司，都要求 java 程序员必需要写 toString
    /// 描述对象信息，建议在所有的模型中，都添加此方法，会有利于调试！
    override var description: String {
        let keys = ["access_token", "expires_in", "expiresDate", "uid", "screen_name", "avatar_large"]
        
        // dictionaryWithValuesForKeys 同样是 KVC 的方法
        // 将对象转换成字典，只转换 keys 数组中包含的`属性`名称
        // 如果 key 不存在，会直接崩溃
        // 跟 setValuesForKeysWithDictionary 刚好对应的一个方法
        return "\(self.dictionaryWithValuesForKeys(keys))"
    }
    
    /// 保存当前用户账户对象到沙盒
    func saveUserAccount() {
        var path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0]
        // 1. 从 Xcode 7 beta 5 开始，stringByAppendingPathComponent 就变成了 NSString 的方法
        // 2. NSString -> String/ NSArray -> [] / NSDictionary - [] 如果要转换苹果底层提供了`桥接`机制
        // 在转换的时候，不需要 ?/!
        path = (path as NSString).stringByAppendingPathComponent("account.plist")
        
        print(path)
        
        // 会自动调用对象的 encodeWithCoder 方法进行归档
        NSKeyedArchiver.archiveRootObject(self, toFile: path)
    }
    
    // MARK: - NSCoding
    /// 归档（encode 编码），将当前`对象`写入沙盒时使用(二进制数据)，以备后续使用，- 序列化类似
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(access_token, forKey: "access_token")
        // 注意：应该保存过期日期，而不要保存过期时间，如果再次计算会发生错误
        aCoder.encodeObject(expiresDate, forKey: "expiresDate")
        aCoder.encodeObject(uid, forKey: "uid")
        aCoder.encodeObject(screen_name, forKey: "screen_name")
        aCoder.encodeObject(avatar_large, forKey: "avatar_large")
    }
    
    /// 解档(decode解码)，将沙盒中的`文件(二进制数据)`转换成自定义对象 - 反序列类似
    /// 构造函数的作用是创建对象
    required init?(coder aDecoder: NSCoder) {
        
        access_token = aDecoder.decodeObjectForKey("access_token") as? String
        expiresDate = aDecoder.decodeObjectForKey("expiresDate") as? NSDate
        uid = aDecoder.decodeObjectForKey("uid") as? String
        screen_name = aDecoder.decodeObjectForKey("screen_name") as? String
        avatar_large = aDecoder.decodeObjectForKey("avatar_large") as? String
    }
}
