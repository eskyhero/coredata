//
//  BaseTableViewController.swift
//  GZWeibo
//
//  Created by Apple on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

/// 表格控制器基类，处理用户没有登录
class BaseTableViewController: UITableViewController {

    /// 用户登录标记
    var userLogon = UserAccountViewModel.sharedAccountViewModel.userLogon
    
    /// 访客视图 - 如果写成懒加载会有什么问题？
    //lazy var visitorView: VisitorView? = VisitorView()
    var visitorView: VisitorView?
    
    // 创建视图层次结构
    override func loadView() {
        // 如果登录，使用系统默认的视图 － UITableView，否则显示访客视图
        userLogon ? super.loadView() : setupVisitorView()
    }
    
    // 每个继承自 BaseVC 的控制器，都各自有各自的访客视图
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        print("访客视图 \(visitorView)")
    }
    
    ///  设置访客界面
    private func setupVisitorView() {
        visitorView = VisitorView()
        
        view = visitorView
        
        // 添加监听方法
        visitorView?.loginButton.addTarget(self, action: "visitorViewDidLogin", forControlEvents: UIControlEvents.TouchUpInside)
        visitorView?.registerButton.addTarget(self, action: "visitorViewDidRegister", forControlEvents: UIControlEvents.TouchUpInside)
        
        // 添加导航栏按钮
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "注册", style: .Plain, target: self, action: "visitorViewDidRegister")
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "登录", style: .Plain, target: self, action: "visitorViewDidLogin")
    }
    
    // MARK: - 监听方法
    @objc private func visitorViewDidLogin() {
        let vc = OAuthViewController()
        let nav = UINavigationController(rootViewController: vc)
        
        presentViewController(nav, animated: true, completion: nil)
    }
    
    @objc private func visitorViewDidRegister() {
        print("注册")
    }
}
