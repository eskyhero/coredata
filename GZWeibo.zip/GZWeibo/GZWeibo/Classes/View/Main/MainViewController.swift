//
//  MainViewController.swift
//  GZWeibo
//
//  Created by Apple on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

class MainViewController: UITabBarController {

    // MARK: - 监听方法
    /// 点击撰写按钮的方法 - 是运行循环通过消息机制来调用方法
    /// 不能`单纯`的使用 private，一旦使用 private，运行循环无法找到方法，造成崩溃！
    /// 但是：Swift 中默认全局共享，不想共享的方法都建议使用 private
    /// 如果使用 @objc 修饰符号，在编译的时候，会对函数做特殊处理，保证运行循环能够通过消息机制
    /// 访问到此方法
    @objc private func clickComposedButton() {
        
        let logon = UserAccountViewModel.sharedAccountViewModel.userLogon
        let vc = logon ? CompseViewController() : OAuthViewController()
        
        let nav = UINavigationController(rootViewController: vc)
        
        presentViewController(nav, animated: true, completion: nil)
    }
    
    // MARK: - 设置界面
    override func viewDidLoad() {
        super.viewDidLoad()

        // 添加所有子控制器 - 并不会创建 tabBar 中的按钮
        addChildViewControllers()
        
        // 设置撰写按钮
        setupComposedButton()
        
        print(tabBar.subviews)
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        // 视图将要出现的时候，tabBar 中的按钮才会被创建 - 复合 OC 中延迟加载的特点
        print(tabBar.subviews)
        
        // 将撰写按钮移动到最前面
        tabBar.bringSubviewToFront(composedButton)
    }
    
    /// 设置撰写按钮
    private func setupComposedButton() {
        // 1. 添加按钮
        tabBar.addSubview(composedButton)
        
        // 2. 设置按钮位置
        let count = self.childViewControllers.count
        // -1 的目的是为了防止用户点击到按钮的边界
        let w = tabBar.bounds.width / CGFloat(count) - 1
        
        composedButton.frame = CGRectInset(tabBar.bounds, 2 * w, 0)
        
        // 3. 添加监听方法
        composedButton.addTarget(self, action: "clickComposedButton", forControlEvents: .TouchUpInside)
    }
    
    /// 添加所有子控制器
    private func addChildViewControllers() {
        addChildViewController(HomeTableViewController(), title: "首页", imageName: "tabbar_home")
        addChildViewController(MessageTableViewController(), title: "消息", imageName: "tabbar_message_center")
        
        // 添加了一个空的控制器
        addChildViewController(UIViewController())
        
        addChildViewController(DiscoverTableViewController(), title: "发现", imageName: "tabbar_discover")
        addChildViewController(ProfileTableViewController(), title: "我", imageName: "tabbar_profile")
    }

    /// 添加子控制器
    ///
    /// - parameter vc:        控制器
    /// - parameter title:     标题
    /// - parameter imageName: 图片名称
    private func addChildViewController(vc: UIViewController, title: String, imageName: String) {
        // 设置标题 - 从内向外设置
        vc.title = title
        vc.tabBarItem.image = UIImage(named: imageName)
        
        let nav = UINavigationController(rootViewController: vc)
        
        addChildViewController(nav)
    }
    
    // MARK: - 懒加载控件
    private lazy var composedButton: UIButton = UIButton(imageName: "tabbar_compose_icon_add", backImageName: "tabbar_compose_button")
}
