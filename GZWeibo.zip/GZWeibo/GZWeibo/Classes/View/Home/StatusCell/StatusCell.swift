//
//  StatusCell.swift
//  GZWeibo
//
//  Created by Apple on 15/9/25.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SnapKit
import FFLabel

/// 图像宽度
let WBStatusCellIconWidth: CGFloat = 35
/// 控件之间的间距
let WBStatusCellMargin: CGFloat = 12

// MARK: StatusCellDelegate
protocol StatusCellDelegate: NSObjectProtocol {
 
    /// 点击 cell 中的文本链接
    func statusCellDidClickLink(url: NSURL)
}

/// 微博 Cell
class StatusCell: UITableViewCell {

    /// Cell 的代理
    weak var cellDelegate: StatusCellDelegate?
    
    /// 微博数据视图模型
    var viewModel: StatusViewModel? {
        didSet {
            topView.viewModel = viewModel
            
            // 设置微博文字
            let statusText = viewModel?.status.text ?? ""
            contentLabel.attributedText = EmoticonViewModel.sharedViewModel.emoticonText(statusText, font: contentLabel.font)
            
            // 设置配图视图数据
            pictureView.viewModel = viewModel
        }
    }
    
    /// 根据视图模型计算行高
    ///
    /// - parameter vm: 视图模型
    ///
    /// - returns: 行高
    func rowHeight(vm: StatusViewModel) -> CGFloat {
        // 1. 设置视图模型
        viewModel = vm
        
        // 2. 更新约束
        layoutIfNeeded()
        
        // 3. 返回底部视图的最大 Y 值
        return CGRectGetMaxY(bottomView.frame)
    }
    
    // MARK: - 构造函数
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// 设置界面
    func setupUI() {
        // 1. 设置背景颜色
        backgroundColor = UIColor.whiteColor()
        
        // 2. 添加控件
        contentView.addSubview(topView)
        contentView.addSubview(contentLabel)
        contentView.addSubview(pictureView)
        contentView.addSubview(bottomView)
        
        // 3. 自动布局
        topView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(contentView.snp_top)
            make.left.equalTo(contentView.snp_left)
            make.right.equalTo(contentView.snp_right)
            make.height.equalTo(2 * WBStatusCellMargin + WBStatusCellIconWidth)
        }
        
        contentLabel.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(topView.snp_bottom).offset(WBStatusCellMargin)
            make.left.equalTo(contentView.snp_left).offset(WBStatusCellMargin)
        }
        
        bottomView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(pictureView.snp_bottom).offset(WBStatusCellMargin)
            make.left.equalTo(contentView.snp_left)
            make.right.equalTo(contentView.snp_right)
            make.height.equalTo(44)
            
            // 设定底部约束
            // make.bottom.equalTo(contentView.snp_bottom)
        }
        
        // 4. 设置标签代理
        contentLabel.labelDelegate = self
    }
    
    // MARK: - 懒加载控件
    /// 顶部视图
    private lazy var topView: StatusCellTopView = StatusCellTopView()
    /// 内容标签
    lazy var contentLabel: FFLabel = FFLabel(title: "微博正文",
        color: UIColor.darkGrayColor(),
        fontSize: 15,
        layoutWidth: UIScreen.mainScreen().bounds.width - 2 * WBStatusCellMargin)
    /// 配图视图
    lazy var pictureView: StatusCellPictureView = StatusCellPictureView()
    /// 底部视图
    lazy var bottomView: StatusCellBottomView = StatusCellBottomView()
}

// MARK: - FFLabelDelegate
extension StatusCell: FFLabelDelegate {
    
    func labelDidSelectedLinkText(label: FFLabel, text: String) {

        // 1. 判读是否是 URL
        if !text.hasPrefix("http://") {
            return
        }
        
        // 2. 生成 URL 并且调用
        guard let url = NSURL(string: text) else {
            return
        }
        
        // 3. 通知代理
        cellDelegate?.statusCellDidClickLink(url)
    }
}
