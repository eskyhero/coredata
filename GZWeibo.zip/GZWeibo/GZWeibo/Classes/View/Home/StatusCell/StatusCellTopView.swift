//
//  StatusCellTopView.swift
//  GZWeibo
//
//  Created by Apple on 15/9/25.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SnapKit
import SDWebImage

/// 顶部视图
class StatusCellTopView: UIView {
    
    /// 微博数据视图模型
    var viewModel: StatusViewModel? {
        didSet {
            // 头像 - 提示：因为 SDWebImage 是 OC 的，对可选类型要求不严格
            iconView.sd_setImageWithURL(viewModel!.userProfileUrl)
            // 姓名
            nameLabel.text = viewModel?.status.user?.screen_name
            // 设置 vip
            vipIconView.image = viewModel?.userVipImage
            // 设置会员
            memberIconView.image = viewModel?.userMemberImage
            
            // 日期
            timeLabel.text = viewModel?.createAt
            // 微博来源
            sourceLabel.text = viewModel?.status.source
        }
    }
    
    // MARK: - 构造函数
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// 准备界面
    private func setupUI() {
        // 1. 设置背景颜色
        backgroundColor = UIColor.whiteColor()
        
        // 2. 添加控件
        // 添加分割视图
        let sepView = UIView()
        sepView.backgroundColor = UIColor.lightGrayColor()
        addSubview(sepView)
        
        addSubview(iconView)
        addSubview(nameLabel)
        addSubview(memberIconView)
        addSubview(vipIconView)
        addSubview(timeLabel)
        addSubview(sourceLabel)
        
        // 3. 自动布局
        sepView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(snp_top)
            make.left.equalTo(snp_left)
            make.right.equalTo(snp_right)
            make.height.equalTo(WBStatusCellMargin)
        }
        
        iconView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(sepView.snp_bottom).offset(WBStatusCellMargin)
            make.left.equalTo(snp_left).offset(WBStatusCellMargin)
            make.width.equalTo(WBStatusCellIconWidth)
            make.height.equalTo(WBStatusCellIconWidth)
        }
        nameLabel.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(iconView.snp_top)
            make.left.equalTo(iconView.snp_right).offset(WBStatusCellMargin)
        }
        memberIconView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(nameLabel.snp_top)
            make.left.equalTo(nameLabel.snp_right).offset(WBStatusCellMargin)
        }
        vipIconView.snp_makeConstraints { (make) -> Void in
            make.centerX.equalTo(iconView.snp_right)
            make.centerY.equalTo(iconView.snp_bottom)
        }
        timeLabel.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(iconView.snp_bottom)
            make.left.equalTo(iconView.snp_right).offset(WBStatusCellMargin)
        }
        sourceLabel.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(timeLabel.snp_bottom)
            make.left.equalTo(timeLabel.snp_right).offset(WBStatusCellMargin)
        }
    }
    
    // MARK: - 懒加载控件
    /// 1. 头像
    private lazy var iconView: UIImageView = UIImageView(image: UIImage(named: "avatar_default_big"))
    /// 2. 姓名
    private lazy var nameLabel: UILabel = UILabel(title: "刀哥", color: UIColor.darkGrayColor(), fontSize: 14)
    /// 3. 会员图标
    private lazy var memberIconView: UIImageView = UIImageView(image: UIImage(named: "common_icon_membership_level1"))
    /// 4. vip图标
    private lazy var vipIconView: UIImageView = UIImageView(image: UIImage(named: "avatar_grassroot"))
    /// 5. 时间标签
    private lazy var timeLabel: UILabel = UILabel(title: "刚刚", color: UIColor.orangeColor(), fontSize: 10)
    /// 6. 来源标签
    private lazy var sourceLabel: UILabel = UILabel(title: "广州微博", color: UIColor.lightGrayColor(), fontSize: 10)

}
