//
//  StatusCellBottomView.swift
//  GZWeibo
//
//  Created by Apple on 15/9/25.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

/// 底部视图
class StatusCellBottomView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// 设置界面
    private func setupUI() {
        // 1.背景颜色
        backgroundColor = UIColor(white: 0.95, alpha: 1.0)
        
        // 2. 添加控件
        addSubview(forwardButton)
        addSubview(commentButton)
        addSubview(likeButton)
        let sep1 = sepView()
        let sep2 = sepView()
        addSubview(sep1)
        addSubview(sep2)
        
        // 3. 自动布局
        forwardButton.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(snp_top)
            make.left.equalTo(snp_left)
            make.bottom.equalTo(snp_bottom)
        }
        commentButton.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(forwardButton.snp_top)
            make.left.equalTo(forwardButton.snp_right)
            make.width.equalTo(forwardButton.snp_width)
            make.bottom.equalTo(snp_bottom)
        }
        likeButton.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(commentButton.snp_top)
            make.left.equalTo(commentButton.snp_right)
            make.width.equalTo(commentButton.snp_width)
            make.bottom.equalTo(snp_bottom)
            
            // 设定右侧的约束
            make.right.equalTo(snp_right)
        }
        sep1.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(forwardButton.snp_right)
            // 设置一个像素点宽度
            make.width.equalTo(0.5)
            make.height.equalTo(snp_height).multipliedBy(0.6)
            make.centerY.equalTo(snp_centerY)
        }
        sep2.snp_makeConstraints { (make) -> Void in
            make.left.equalTo(commentButton.snp_right)
            make.width.equalTo(0.5)
            make.height.equalTo(snp_height).multipliedBy(0.6)
            make.centerY.equalTo(snp_centerY)
        }
    }
    
    /// 建立分割线视图
    private func sepView() -> UIView {
        let v = UIView()
        
        // 如果能够用颜色，就不要用图片
        v.backgroundColor = UIColor.darkGrayColor()
        
        return v
    }

    // MARK: - 懒加载控件
    /// 转发按钮
    private lazy var forwardButton: UIButton = UIButton(title: " 转发",
        fontSize: 12,
        color: UIColor.darkGrayColor(),
        imageName: "timeline_icon_retweet")
    /// 评论按钮
    private lazy var commentButton: UIButton = UIButton(title: " 评论",
        fontSize: 12,
        color: UIColor.darkGrayColor(),
        imageName: "timeline_icon_comment")
    /// 点赞按钮
    private lazy var likeButton: UIButton = UIButton(title: " 赞",
        fontSize: 12,
        color: UIColor.darkGrayColor(),
        imageName: "timeline_icon_unlike")
    
}
