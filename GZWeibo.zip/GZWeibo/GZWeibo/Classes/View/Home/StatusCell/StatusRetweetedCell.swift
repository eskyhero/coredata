//
//  StatusRetweetedCell.swift
//  GZWeibo
//
//  Created by Apple on 15/9/28.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SnapKit
import FFLabel

/// 转发微博 Cell
class StatusRetweetedCell: StatusCell {

    /// 微博数据视图模型
    /// 如果在子类中重写了父类的属性，父类的 didSet 会先被调用，然后再调用子类的 didSet 
    /// 不需要 super
    override var viewModel: StatusViewModel? {
        didSet {
            // 设置转发微博的文字
            let statusText = viewModel?.retweetedText ?? ""
            retweetedLabel.attributedText = EmoticonViewModel.sharedViewModel.emoticonText(statusText, font: retweetedLabel.font)
            
            // 修改配图视图约束
            pictureView.snp_updateConstraints { (make) -> Void in
                // 使用计算完成的大小，设置约束数值！
                make.width.equalTo(pictureView.bounds.width)
                make.height.equalTo(pictureView.bounds.height)
                
                let offset = (pictureView.bounds.height == 0) ? 0 : WBStatusCellMargin
                make.top.equalTo(retweetedLabel.snp_bottom).offset(offset)
            }
        }
    }
    
    /// 设置界面
    override func setupUI() {
        // 调用父类方法，可以让父类方法完成父类控件的添加和布局
        super.setupUI()
        
        // 添加控件
        contentView.insertSubview(backButton, belowSubview: pictureView)
        contentView.insertSubview(retweetedLabel, aboveSubview: backButton)
        
        // 自动布局
        backButton.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(contentLabel.snp_bottom).offset(WBStatusCellMargin)
            make.left.equalTo(contentView.snp_left)
            make.right.equalTo(contentView.snp_right)
            make.bottom.equalTo(bottomView.snp_top)
        }
        
        retweetedLabel.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(backButton.snp_top).offset(WBStatusCellMargin)
            make.left.equalTo(backButton.snp_left).offset(WBStatusCellMargin)
        }
        
        // 设置配图视图的约束！
        pictureView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(retweetedLabel.snp_bottom).offset(WBStatusCellMargin)
            make.left.equalTo(retweetedLabel.snp_left)
            make.width.equalTo(290)
            make.height.equalTo(290)
        }
        
        // 设置代理 － 父类实现了协议方法，如果不做特殊处理，点击链接会调用父类的方法
        retweetedLabel.labelDelegate = self
    }
    
    // MARK: - 懒加载控件
    /// 背景按钮
    private lazy var backButton: UIButton = {
        let button = UIButton()
        
        button.backgroundColor = UIColor(white: 0.9, alpha: 1.0)
        
        return button
    }()
    
    /// 转发文字标签
    private lazy var retweetedLabel: FFLabel = FFLabel(title: "转发微博",
        color: UIColor.darkGrayColor(),
        fontSize: 14,
        layoutWidth: UIScreen.mainScreen().bounds.width - 2 * WBStatusCellMargin)
}
