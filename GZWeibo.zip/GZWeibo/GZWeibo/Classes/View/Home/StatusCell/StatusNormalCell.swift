//
//  StatusNormalCell.swift
//  GZWeibo
//
//  Created by Apple on 15/9/28.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

/// 原创微博 Cell
class StatusNormalCell: StatusCell {

    /// 微博数据视图模型
    override var viewModel: StatusViewModel? {
        didSet {
            // 修改配图视图高度
            pictureView.snp_updateConstraints { (make) -> Void in
                // 使用计算完成的大小，设置约束数值！
                make.width.equalTo(pictureView.bounds.width)
                make.height.equalTo(pictureView.bounds.height)

                let offset = (pictureView.bounds.height == 0) ? 0 : WBStatusCellMargin
                make.top.equalTo(contentLabel.snp_bottom).offset(offset)
            }
        }
    }
    
    /// 设置界面
    override func setupUI() {
        super.setupUI()
        
        pictureView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(contentLabel.snp_bottom).offset(WBStatusCellMargin)
            make.left.equalTo(contentLabel.snp_left)
            make.width.equalTo(290)
            make.height.equalTo(290)
        }
    }
}
