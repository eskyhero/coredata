//
//  StatusCellPictureView.swift
//  GZWeibo
//
//  Created by Apple on 15/9/25.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SDWebImage

/// 图片默认大小
private let StatusPictureItemWidth: CGFloat = 90
/// 图片默认间距
private let StatusPictureItemMargin: CGFloat = 10
/// 配图 Cell 可重用 ID
private let StatusPictureCellID = "StatusPictureCellID"

/// 微博 Cell 配图视图
class StatusCellPictureView: UICollectionView {
    
    /// 微博数据视图模型
    var viewModel: StatusViewModel? {
        didSet {
            // 计算大小
            sizeToFit()
            
            // 因为 cell 中的 collectionView，同样会被复用
            // 当视图模型中的数据发生变化时，一定要刷新数据，否则不再调用数据源方法了！
            reloadData()
        }
    }
    
    override func sizeThatFits(size: CGSize) -> CGSize {
        return calcViewSize()
    }
    
    /// 根据配图数量计算视图大小
    private func calcViewSize() -> CGSize {
        // 0. 准备工作
        // 取出当前的布局属性
        let layout = collectionViewLayout as! UICollectionViewFlowLayout
        layout.itemSize = CGSize(width: StatusPictureItemWidth, height: StatusPictureItemWidth)
        
        // 每行显示的图片数
        let rowCount = 3
        // 图片数量
        let count = viewModel?.thumbnailUrls?.count ?? 0
        
        // 1. 没有图
        if count == 0 {
            return CGSizeZero
        }
        
        // 2. 单张图
        if count == 1 {
            var size = CGSize(width: 150, height: 150)
            
            // 使用 SDWebImage 的缓存函数
            let key = viewModel!.thumbnailUrls![0].absoluteString
            
            // 查询是否有磁盘缓存的图像，key 是 url 的完整路径字符串
            if let image = SDWebImageManager.sharedManager().imageCache.imageFromDiskCacheForKey(key) {
                size = image.size
            }
            
            // 图片处理细节
            // 1> 过窄的图像
            size.width = size.width < 40 ? 40 : size.width
            // 2> 过宽的图像
            if size.width > 300 {
                // 定宽
                let w: CGFloat = 150
                // 等比例计算高度
                let h = size.height * w / size.width
                
                size = CGSize(width: w, height: h)
            }
            
            layout.itemSize = size
            return size
        }
        
        // 3. 4张图 2 * 2的格式
        if count == 4 {
            let w = 2 * StatusPictureItemWidth + StatusPictureItemMargin
            
            return CGSize(width: w, height: w)
        }
        
        // 4. 其他 按照九宫格的方式计算
        /**
            宽度可以固定显示三张，需要计算行数，根据行数可以计算出高度
            2 3         1 2
            5 6         4 5
            7 8 9       6 7 8
        */
        let row = CGFloat((count - 1) / rowCount + 1)
        let w = CGFloat(rowCount) * StatusPictureItemWidth + CGFloat(rowCount - 1) * StatusPictureItemMargin
        let h = row * StatusPictureItemWidth + (row - 1) * StatusPictureItemMargin
        
        return CGSize(width: w, height: h)
    }
    
    // MARK: - 构造函数
    init() {
        let layout = UICollectionViewFlowLayout()
        
        layout.itemSize = CGSize(width: StatusPictureItemWidth, height: StatusPictureItemWidth)
        layout.minimumInteritemSpacing = StatusPictureItemMargin
        layout.minimumLineSpacing = StatusPictureItemMargin
        
        super.init(frame: CGRectZero, collectionViewLayout: layout)
        
        backgroundColor = UIColor.lightGrayColor()
        
        // 设置数据源，自己提供数据源
        // dataSource 和 delegate 都是弱引用，不会形成循环引用
        // 通常在开发时，一个`独立的控件或者视图`，偶尔会有这种情况
        dataSource = self
        // 注册可重用 cell
        registerClass(StatusPictureCell.self, forCellWithReuseIdentifier: StatusPictureCellID)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - UICollectionViewDataSource
extension StatusCellPictureView: UICollectionViewDataSource {
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // ?? 是在数据源中使用最常用到的
        return viewModel?.thumbnailUrls?.count ?? 0
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(StatusPictureCellID, forIndexPath: indexPath) as! StatusPictureCell
        
        cell.imageUrl = viewModel!.thumbnailUrls![indexPath.item]
        
        return cell
    }
}

/// 配图视图 cell
private class StatusPictureCell: UICollectionViewCell {
    
    var imageUrl: NSURL? {
        didSet {
            iconView.sd_setImageWithURL(imageUrl)
        }
    }
    
    // MARK: - 构造函数
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        contentView.addSubview(iconView)
        
        // 自动布局，不能设置 frame
        iconView.snp_makeConstraints { (make) -> Void in
            // 使用 edges 可以同时设置上下左右的边界，完全填充
            make.edges.equalTo(contentView.snp_edges)
        }
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - 懒加载控件
    private lazy var iconView: UIImageView = {
     
        let iv = UIImageView()
        
        iv.contentMode = UIViewContentMode.ScaleAspectFill
        // 裁减图片
        iv.clipsToBounds = true
        
        return iv
    }()
}
