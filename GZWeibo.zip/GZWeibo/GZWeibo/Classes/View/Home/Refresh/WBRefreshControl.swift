//
//  WBRefreshControl.swift
//  GZWeibo
//
//  Created by Apple on 15/9/28.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SnapKit

/// 下拉刷新偏移量
private let WBRefreshControlOffset: CGFloat = -60

/// 自定义刷新控件 - 负责刷新控制
class WBRefreshControl: UIRefreshControl {

    // MARK: - 重写结束刷新方法
    override func endRefreshing() {
        super.endRefreshing()
        
        refreshView.stopLoadingAnim()
    }
    
    // MARK: - KVO 方法
    /**
        1. 向下拉，y值变小
        2. 向上推，y值变大
        3. 临界点 y == 0
        4. 下拉到一定程度，会自动进入刷新状态
    */
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        
        if frame.origin.y > 0 {
            return
        }
        
        // 判断是否开始刷新，只要刷新开始，或者进行中，都是 true
        if refreshing {
            refreshView.startLoadingAnim()
            return
        }
        
        if frame.origin.y < WBRefreshControlOffset && !refreshView.rotateFlag {
            print("翻过来")
            refreshView.rotateFlag = true
        } else if frame.origin.y >= WBRefreshControlOffset && refreshView.rotateFlag {
            print("转过去")
            refreshView.rotateFlag = false
        }
    }
    
    // MARK: - 构造函数
    override init() {
        super.init()
        
        setupUI()
    }
    
    deinit {
        // 注销监听
        self.removeObserver(self, forKeyPath: "frame")
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        setupUI()
    }
    
    private func setupUI() {
        // 隐藏菊花
        tintColor = UIColor.clearColor()
        
        // 添加控件
        addSubview(refreshView)
        
        // 指定布局 － 使用 XIB 布局的时候，大小会随着 XIB 中的设置，但是在布局的时候，需要指定
        refreshView.snp_makeConstraints { (make) -> Void in
            make.center.equalTo(snp_center)
            make.width.equalTo(refreshView.bounds.width)
            make.height.equalTo(refreshView.bounds.height)
        }
        
        // 利用 KVO 监听 `frame` 属性变化
        self.addObserver(self, forKeyPath: "frame", options: [], context: nil)
    }
    
    // MARK: - 懒加载控件
    private lazy var refreshView = WBRefreshView.refreshView()
}

/// 自定义刷新视图 - 负责显示动画的
class WBRefreshView: UIView {
    
    /// 旋转标记
    var rotateFlag = false {
        didSet {
            rotateTipIcon()
        }
    }
    
    /// 加载图标
    @IBOutlet weak var loadingIcon: UIImageView!
    /// 提示视图
    @IBOutlet weak var tipView: UIView!
    /// 旋转提示图标
    @IBOutlet weak var tipIcon: UIImageView!
    
    /// 从 XIB 加载 刷新视图
    class func refreshView() -> WBRefreshView {
        return NSBundle.mainBundle().loadNibNamed("WBRefreshView", owner: nil, options: nil)[0] as! WBRefreshView
    }
    
    /// 旋转提示图标动画
    private func rotateTipIcon() {
        var angle = CGFloat(M_PI)
        angle += rotateFlag ? -0.001 : 0.001
        
        // 在 iOS 旋转块动画中，有两个原则
        // 1. 就近原则
        // 2. 顺时针优先
        UIView.animateWithDuration(0.5) { () -> Void in
            self.tipIcon.transform = CGAffineTransformRotate(self.tipIcon.transform, angle)
        }
    }
    
    /// 开始加载动画
    private func startLoadingAnim() {
        
        let keyPath = "transform.rotation"
        
        // 判断动画是否已经被添加，如果添加，就不会再次添加
        if loadingIcon.layer.animationForKey(keyPath) != nil {
            return
        }
        
        tipView.hidden = true
        
        let anim = CABasicAnimation(keyPath: keyPath)
        
        anim.toValue = 2 * M_PI
        anim.repeatCount = MAXFLOAT
        anim.duration = 0.5
        // 通常用在连续播放的动画中，会随着图像的销毁一起被销毁
        anim.removedOnCompletion = false
        
        loadingIcon.layer.addAnimation(anim, forKey: keyPath)
    }
    
    /// 停止加载动画
    private func stopLoadingAnim() {
        tipView.hidden = false
        
        loadingIcon.layer.removeAllAnimations()
    }
}
