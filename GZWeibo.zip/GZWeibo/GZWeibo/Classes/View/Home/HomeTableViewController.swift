//
//  HomeTableViewController.swift
//  GZWeibo
//
//  Created by Apple on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SVProgressHUD

/// 原创微博的可重用标示符
let WBHomeNormalCellID = "WBHomeNormalCellID"
/// 转发微博的可重用标示符
let WBHomeRetweetedCellID = "WBHomeRetweetedCellID"

class HomeTableViewController: BaseTableViewController {

    // 定义一个微博列表的视图模型属性
    lazy var listViewModel = StatusListViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if !UserAccountViewModel.sharedAccountViewModel.userLogon {
            // 如果用户登录成功，visitorView == nil，不会调用后面的方法！
            visitorView?.setupInfo(nil, title: "关注一些人，回这里看看有什么惊喜")
            return
        }
        
        prepareTableView()
        loadData()
    }
    
    /// 准备表格属性 - 不要在`主方法`中写碎代码 - 提高代码的可读性
    /// 小方法，就放在主方法的下方或者上方
    private func prepareTableView() {
        // 注册可重用 cell - 一个表格可以注册多个可重用 cell
        tableView.registerClass(StatusNormalCell.self, forCellReuseIdentifier: WBHomeNormalCellID)
        tableView.registerClass(StatusRetweetedCell.self, forCellReuseIdentifier: WBHomeRetweetedCellID)
        
        // 设置预估行高
        tableView.estimatedRowHeight = 300
        
        // 取消分割线
        tableView.separatorStyle = .None
        
        // 下拉刷新控件 － 高度 60 点
        refreshControl = WBRefreshControl()
        
        refreshControl?.addTarget(self, action: "loadData", forControlEvents: UIControlEvents.ValueChanged)
        
        // 上拉控件
        tableView.tableFooterView = pullupView
    }
    
    /// 加载数据
    @objc private func loadData() {
        
        // 播放刷新控件，不会触发刷新的监听方法
        refreshControl?.beginRefreshing()

        // 以上拉刷新控件事否动画判断是否是上拉刷新
        listViewModel.loadStatus(isPullup: pullupView.isAnimating()) { (error) -> () in
            // 关闭刷新控件
            self.refreshControl?.endRefreshing()
            // 关闭上拉刷新控件
            self.pullupView.stopAnimating()
            
            if error != nil {
                SVProgressHUD.showInfoWithStatus("您的网路不给力")
                return
            }
            
            print("下拉刷新的数据行数 \(self.listViewModel.pulldownCount)")
            self.showPulldownTip()
            
            // 到此为止已经有数据了
            //print(self.listViewModel.statuses)
            // 刷新表格
            self.tableView.reloadData()
        }
    }
    
    /// 显示下拉刷新提示
    private func showPulldownTip() {
        // 判断是否下拉刷新
        guard let count = listViewModel.pulldownCount else {
            print("不是下拉刷新")
            return
        }
        
        let title = count == 0 ? "没有新微博" : "刷新到 \(count) 条微博"
        pulldownTipLabel.text = title

        // 初始位置
        let h: CGFloat = 44
        // navBar 高度是 44
        // 提示: iOS NavBar/ToolBar/TabBar 都不能使用自动布局，内部的布局都是底层封装的
        let rect = CGRect(x: 0, y: -2 * h, width: view.bounds.width, height: h)
        pulldownTipLabel.frame = rect
        
        // 动画
        UIView.animateWithDuration(1.0, animations: { () -> Void in
            self.pulldownTipLabel.frame = CGRectOffset(rect, 0, 3 * h)
            }) { (_) -> Void in
                
                UIView.animateWithDuration(1.0) { self.pulldownTipLabel.frame = rect }
        }
    }
    
    // MARK: - 懒加载控件
    private lazy var pulldownTipLabel: UILabel = {
        let label = UILabel(title: "", color: UIColor.whiteColor(), fontSize: 18)
        label.backgroundColor = UIColor.orangeColor()
        
        // 在开发的时候，可以借助 navbar 来做相对屏幕固定的控件，不会随着表格滚动
        self.navigationController?.navigationBar.insertSubview(label, atIndex: 0)
        
        return label
    }()
    /// 上拉刷新控件
    private lazy var pullupView: UIActivityIndicatorView = {
      
        let indicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.WhiteLarge)
        
        indicator.color = UIColor.darkGrayColor()
        
        return indicator
    }()
}

// MARK: - UITableViewDataSource
// 提示：因为已经遵守过协议，所以不必再次遵守
extension HomeTableViewController {
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listViewModel.statuses.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        // 1. 取出视图模型
        let vm = listViewModel.statuses[indexPath.row]
        
        // 2. 获取可重用 cell
        let cell = tableView.dequeueReusableCellWithIdentifier(vm.cellId, forIndexPath: indexPath) as! StatusCell
        
        // 3. 设置视图模型
        cell.viewModel = vm
        
        // 4. 如果是最后一条数据，开始上拉刷新
        if indexPath.row == listViewModel.statuses.count - 1 && !pullupView.isAnimating() {
            print("开始上拉刷新")
            pullupView.startAnimating()
            // 加载数据
            loadData()
        }
        
        // 5. 设置 cell 的文本点击代理
        cell.cellDelegate = self
        
        return cell
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {

        return listViewModel.statuses[indexPath.row].rowHeight
    }
}

// MARK: - StatusCellDelegate
extension HomeTableViewController: StatusCellDelegate {
    
    func statusCellDidClickLink(url: NSURL) {
        print(url)
        
        let vc = HomeWebViewController(url: url)
        
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
}
