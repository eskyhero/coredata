//
//  OAuthViewController.swift
//  GZWeibo
//
//  Created by Apple on 15/9/22.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SVProgressHUD

/// 登录 OAuth 控制器
class OAuthViewController: UIViewController {

    /// webView
    private lazy var webView = UIWebView()
    
    // MARK: - 监听方法
    @objc private func close() {
        SVProgressHUD.dismiss()
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    /// 自动填充用户信息
    @objc private func autoFill() {
        let js = "document.getElementById('userId').value = 'daoge10000@sina.cn';" +
            "document.getElementById('passwd').value = 'qqq123';"
        
        // 让 webView 执行 js
        webView.stringByEvaluatingJavaScriptFromString(js)
    }
    
    override func loadView() {
        view = webView
        webView.delegate = self
        
        // 设置导航栏
        title = "登录新浪微博"
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "关闭", style: .Plain, target: self, action: "close")
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "自动填充", style: .Plain, target: self, action: "autoFill")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // 加载授权页面
        webView.loadRequest(NSURLRequest(URL: NetworkTools.sharedTools.oauthURL))
    }
}

/// MARK: - UIWebViewDelegate - 在 extension 中包装所有的代理方法，让方法相对更加集中
extension OAuthViewController: UIWebViewDelegate {
    
    func webViewDidStartLoad(webView: UIWebView) {
        SVProgressHUD.show()
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        SVProgressHUD.dismiss()
    }
    
    func webView(webView: UIWebView, didFailLoadWithError error: NSError?) {
        print("加载失败 \(error)")
    }
    
    /// 是否加载请求的代理方法
    ///
    /// - parameter webView:        webView
    /// - parameter request:        要加载的 请求
    /// - parameter navigationType: 导航类型
    ///
    /// - returns: 决定是否加载 request
    /// - 提示：在 iOS 的代理方法中，如果要求返回 Bool，通常返回 true，表示一切正常
    /**
        1. 从 URL 中获得 code
        https://www.baidu.com/?code=b3518c086845a540b3a7c45c8c3f7419
        2. 取消授权
        https://www.baidu.com/?error_uri=%2Foauth2%2Fauthorize&error=...
    
        从上面两个地址判断用户是否授权成功，但是百度的页面不能显示给用户！
    
        3. 其他的地址都是微博官方地址，需要加载
    */
    func webView(webView: UIWebView, shouldStartLoadWithRequest request: NSURLRequest, navigationType: UIWebViewNavigationType) -> Bool {
        
        // 1. 判断完整 URL 字符串中是否包含回调地址，屏蔽百度页面的显示
        if !request.URL!.absoluteString.hasPrefix(NetworkTools.sharedTools.redirectURI) {
            return true
        }
        
        // 2. 从回调地址的请求 URL 的 query 中提取 code= 之后的内容 -> 请求码
        if let query = request.URL?.query where query.hasPrefix("code=") {
            
            // 提取请求码
            let code = query.substringFromIndex("code=".endIndex)
            
            print("请求码是 --- " + code)
            UserAccountViewModel.sharedAccountViewModel.loadAccessToken(code, finished: { (error) -> () in
                
                if error != nil {
                    SVProgressHUD.showInfoWithStatus("您的网络不给力!")
                    
                    return
                }
                
                SVProgressHUD.showInfoWithStatus("登录成功")
                
                // *** 一定要等待控制器被销毁后，再发送通知
                self.dismissViewControllerAnimated(false, completion: { () -> Void in
                    // 控制器被销毁后再执行的代码
                    NSNotificationCenter.defaultCenter().postNotificationName(WBSwitchRootViewControllerNotification, object: "Welcome")
                })
                
            })
            return false
        }
        
        close()
        return false
    }
}
