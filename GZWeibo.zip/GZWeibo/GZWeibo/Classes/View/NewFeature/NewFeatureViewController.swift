//
//  NewFeatureViewController.swift
//  GZWeibo
//
//  Created by Apple on 15/9/24.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SnapKit

// MARK: - 私有常量
/// 新特性图片数量
private let WBNewFeatureImageCount = 4
/// 新特性可重用 Cell 标示符号
private let WBNewFeatureReuseIdentifier = "Cell"

class NewFeatureViewController: UICollectionViewController {

    // MARK: - 构造函数
    /// 没有 override 说明 init 函数不是`指定`的构造函数
    /// 实现 init() 函数，可以保证外部调用的简单！
    init() {
        let layout = UICollectionViewFlowLayout()
        
        // 设置布局属性
        layout.itemSize = UIScreen.mainScreen().bounds.size
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        layout.scrollDirection = UICollectionViewScrollDirection.Horizontal
        
        // 提示：布局参数千万不要错 `Flow`
        super.init(collectionViewLayout: layout)
        
        // 一定要调用 父类的构造函数，保证把 父类的控件创建完成
        collectionView?.pagingEnabled = true
        collectionView?.showsHorizontalScrollIndicator = false
        // 弹簧效果
        collectionView?.bounces = false
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Register cell classes
        self.collectionView!.registerClass(NewFeatureCell.self, forCellWithReuseIdentifier: WBNewFeatureReuseIdentifier)
    }

    // MARK: UICollectionViewDataSource - 数据源方法
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return WBNewFeatureImageCount
    }

    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        // 查询可重用 cell
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(WBNewFeatureReuseIdentifier, forIndexPath: indexPath) as! NewFeatureCell
    
        // Configure the cell
        cell.imageIndex = indexPath.item
    
        return cell
    }
    
    // 注意：indexPath 是之前离开屏幕的 indexPath，并不是正在显示的 indexPath
    override func collectionView(collectionView: UICollectionView, didEndDisplayingCell cell: UICollectionViewCell, forItemAtIndexPath indexPath: NSIndexPath) {
        
        // 1. 获取当前显示的 indexPath
        let path = collectionView.indexPathsForVisibleItems()[0]
        
        // 2. 判断 path 是否是最后一项
        if path.item == WBNewFeatureImageCount - 1 {
            // 1> 根据 path 获取到 cell
            (collectionView.cellForItemAtIndexPath(path) as! NewFeatureCell).startButtonAnim()
        }
    }
}

/// 新特性的 Cell
/// 当前类和 控制器 的类在同一个文件
/// 1. cell 代码非常简单
/// 2. 不想让其他人访问
private class NewFeatureCell: UICollectionViewCell {
    
    /// 要显示图像的编号！
    var imageIndex: Int = 0 {
        didSet {
            // 类似于 OC 中的用模型设置 UI
            iconView.image = UIImage(named: "new_feature_\(imageIndex + 1)")
            // 隐藏按钮
            startButton.hidden = true
        }
    }
    
    @objc private func clickStartButton() {
        print("开始体验")
        // 发送通知
        NSNotificationCenter.defaultCenter().postNotificationName(WBSwitchRootViewControllerNotification, object: nil)
    }
    
    /// 播放按钮动画
    private func startButtonAnim() {
        startButton.hidden = false
        startButton.transform = CGAffineTransformMakeScale(0, 0)
        startButton.userInteractionEnabled = false
        
        // 1. usingSpringWithDamping 0.0-1.0 0最弹
        // 2. initialSpringVelocity 初始速度，如果使用 0，近似于重力加速度
        UIView.animateWithDuration(1.0, delay: 0.0, usingSpringWithDamping: 0.8, initialSpringVelocity: 10, options: [], animations: { () -> Void in
            
            self.startButton.transform = CGAffineTransformIdentity
            
            }) { (_) -> Void in
                self.startButton.userInteractionEnabled = true
        }
    }
    
    // MARK: - 构造函数
    // 1. frame 是和 layout 指定的大小一致
    // 2. cell 是可重用的，最多只会有两个
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        print("构造函数 cell \(frame) \(bounds)")
        
        // 1. 添加控件
        contentView.addSubview(iconView)
        contentView.addSubview(startButton)
        
        // 2. 自动布局 － 如果大小是固定的，而且能够获取到的，类似于全屏，可以直接设置 frame
        iconView.frame = bounds
        
        startButton.snp_makeConstraints { (make) -> Void in
            make.centerX.equalTo(snp_centerX)
            make.bottom.equalTo(snp_bottom).offset(-160)
        }
        
        // 隐藏按钮 - 后面如果重用，还会显示
        // startButton.hidden = true
        
        // 3. 添加监听方法
        startButton.addTarget(self, action: "clickStartButton", forControlEvents: .TouchUpInside)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - 懒加载控件
    /// 图片
    private lazy var iconView = UIImageView()
    /// 开始体验按钮
    private lazy var startButton: UIButton = UIButton(title: "开始体验", fontSize: 18, color: UIColor.whiteColor(), backImageName: "new_feature_finish_button")
}

