//
//  WelcomeViewController.swift
//  GZWeibo
//
//  Created by Apple on 15/9/24.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SnapKit
import SDWebImage

class WelcomeViewController: UIViewController {

    // MARK: - 设置头像
    /// 加载数据
    override func viewDidLoad() {
        super.viewDidLoad()
        
        iconView.sd_setImageWithURL(UserAccountViewModel.sharedAccountViewModel.avatarUrl)
    }
    
    // MARK: - 界面动画
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        // 修改图片视图的约束，如果控件已经添加了约束，要修改使用 update
        // ---- 将所有要修改的约束依次设置 ----
        iconView.snp_updateConstraints { (make) -> Void in
            make.bottom.equalTo(view.snp_bottom).offset(-view.bounds.height + 160)
        }
        messageLabel.alpha = 0
        
        // 使用自动布局，后台有一个`自动布局系统`，会在每一次运行循环中，`收集`约束的变化
        // 会在运行循环结束前，调用 layoutSubViews 设置每一个控件的 `frame`
        // 原则：使用了自动布局之后，就不要在代码中，直接修改添加了约束的控件的 frame
        // 如果：想要提前更新约束，调用 layoutIfNeed 会让自动布局系统按照当前收集到的约束进行修改！
        // --- 使用 块动画，更新布局 ---
        UIView.animateWithDuration(1.0, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: [], animations: { () -> Void in
            
            // 如果需要更新动画
            self.view.layoutIfNeeded()
            
            }) { (_) -> Void in
                
                UIView.animateWithDuration(0.5, animations: { () -> Void in
                    
                    self.messageLabel.alpha = 1
                    
                    }, completion: { (_) -> Void in
                        // 切换界面
                        // UIApplication.sharedApplication().keyWindow?.rootViewController = MainViewController()
                        // 发送通知
                        NSNotificationCenter.defaultCenter().postNotificationName(WBSwitchRootViewControllerNotification, object: nil)
                })
        }
    }
    
    // MARK: - 搭建界面
    override func loadView() {
        // 1. 创建视图 － 根视图是 imageView
        view = UIImageView(image: UIImage(named: "ad_background"))
        
        // 2. 添加控件
        view.addSubview(iconView)
        view.addSubview(messageLabel)
        
        // 3. 自动布局
        iconView.snp_makeConstraints { (make) -> Void in
            make.centerX.equalTo(view.snp_centerX)
            make.bottom.equalTo(view.snp_bottom).offset(-160)
            make.width.equalTo(90)
            make.height.equalTo(90)
        }
        messageLabel.snp_makeConstraints { (make) -> Void in
            make.centerX.equalTo(iconView.snp_centerX)
            make.top.equalTo(iconView.snp_bottom).offset(16)
        }
        messageLabel.alpha = 0
    }
    
    // MARK: - 懒加载控件
    /// 头像图片
    private lazy var iconView: UIImageView = {
        let iv = UIImageView(image: UIImage(named: "avatar_default_big"))
        
        // 设置圆角
        iv.layer.cornerRadius = 45
        iv.layer.masksToBounds = true
        
        return iv
    }()
    /// 消息文字
    private lazy var messageLabel: UILabel = UILabel(title: "欢迎归来", color: UIColor.darkGrayColor(), fontSize: 18)

}
