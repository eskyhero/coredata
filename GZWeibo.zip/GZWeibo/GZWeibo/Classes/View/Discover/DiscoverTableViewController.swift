//
//  DiscoverTableViewController.swift
//  GZWeibo
//
//  Created by Apple on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

class DiscoverTableViewController: BaseTableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        visitorView?.setupInfo("visitordiscover_image_profile", title: "登录后，最新、最热微博尽在掌握，不再会与实事潮流擦肩而过")
    }
}
