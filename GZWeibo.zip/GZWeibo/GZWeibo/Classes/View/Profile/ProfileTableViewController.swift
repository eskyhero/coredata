//
//  ProfileTableViewController.swift
//  GZWeibo
//
//  Created by Apple on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

class ProfileTableViewController: BaseTableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        visitorView?.setupInfo("visitordiscover_image_profile", title: "登录后，你的微博、相册、个人资料会显示在这里，展示给别人")
    }
}
