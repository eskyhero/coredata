//
//  StatusListViewModel.swift
//  GZWeibo
//
//  Created by Apple on 15/9/25.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit
import SDWebImage

/// 微博`数据的列表`视图模型
/**
    1. 没有继承自 NSObject - 如果用 OC，继承一下就可以
    2. 没有使用单例 - 因为用户每一次刷新微博，都是要最新的
        用户账户的用单例，因为只有一个账户，避免重复从沙盒加载归档文件 

    日常开发中，使用`单例`要谨慎，单例都是为了解决性能问题！
*/
class StatusListViewModel {
    
    /// 微博数据的数组懒加载
    lazy var statuses = [StatusViewModel]()
    /// 下拉刷新数据行数
    var pulldownCount: Int?
    
    // MARK: - 网络方法
    /// 加载微博数组
    ///
    /// - parameter isPullup: 是否上拉标记
    /// - parameter finished: 完成回调
    func loadStatus(isPullup isPullup: Bool, finished: (error: NSError?)->()) {
        
        // 下拉刷新 since_id：取数组的第一条记录(如果存在)
        // 第一次运行，statuses数组中没有数据，since_id = 0，刷新最新的20条
        // 后续运行的时候，statuses数组中已经有数据，取出第一条数据，刷新比第一条数据新的微博
        var since_id = statuses.first?.status.id ?? 0
        
        // 上拉刷新，找比数组中最后一条微博id小的数据
        var max_id = 0
        if isPullup {
            max_id = statuses.last?.status.id ?? 0
            since_id = 0
        }
        
        StatusDAL.loadStatus(since_id, max_id: max_id) { (array, error) -> () in
            
            // 1. 判断错误
            if error != nil {
                finished(error: error)
                return
            }
            
            // 2. 遍历数组，字典转模型
            // 1> 创建一个可变的微博模型数组
            var arrayM = [StatusViewModel]()
            
            // 2> 遍历
            for dict in array! {
                arrayM.append(StatusViewModel(status: Status(dict: dict)))
            }
            
            print("加载了 \(arrayM.count) 条数据")
            
            // 只有下拉刷新才记录刷新行数
            self.pulldownCount = since_id > 0 ? arrayM.count : nil
            
            // 3> 拼接数组
            // 如果是上拉刷新，将数组追加到末尾
            if max_id > 0 {
                self.statuses += arrayM
            } else {
                // 下拉刷新或者初始刷新，新的微博追加到数组的前面
                self.statuses = arrayM + self.statuses
            }
            
            // 4> 缓存网路图片
            self.cacheWebImage(arrayM, finished: finished)
        }
    }
    
    /// 缓存指定视图模型数组中的`单张`图片
    private func cacheWebImage(array: [StatusViewModel], finished: (error: NSError?)->()) {
        
        // 1> 创建调度组
        let group = dispatch_group_create()
        // 定义数据长度
        var dataLength = 0
        
        // 遍历数组中的每一个视图模型
        for vm in array {
            
            // 1. 判断图片的数量是否为 1
            if vm.thumbnailUrls?.count != 1 {
                continue
            }
            
            // 2. 肯定是单张图片
            let url = vm.thumbnailUrls![0]
            print("缓存单张图像 \(url)")
            
            // 3. 使用 SDWebImage 的核心函数下载图片
            // 2> 入组
            dispatch_group_enter(group)
            SDWebImageManager.sharedManager().downloadImageWithURL(url, options: [], progress: nil, completed: { (image, _, _, _, _) -> Void in
                
                // image 一定有值吗！
                // 将 image 转换成二进制数据
                if let img = image,
                    data = UIImagePNGRepresentation(img) {
                    
                        // 累加数据长度
                        dataLength += data.length
                }
                
                // 3> 出组
                dispatch_group_leave(group)
            })
        }
        
        // 4> 监听群组动作
        dispatch_group_notify(group, dispatch_get_main_queue()) { () -> Void in
            print("缓存完成 \(dataLength / 1024) K")
            
            // 5> 通知调用方 － 网络访问结束
            finished(error: nil)
        }
    }
}
