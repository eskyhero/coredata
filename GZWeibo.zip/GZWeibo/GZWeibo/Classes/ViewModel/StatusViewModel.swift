//
//  StatusViewModel.swift
//  GZWeibo
//
//  Created by Apple on 15/9/25.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

/// 微博的视图模型
/**
    对于没有`父类`的 class，如果要编写调试信息，需要遵守 CustomStringConvertible
    然后实现 var description: String
*/
class StatusViewModel: CustomStringConvertible {
    
    /// 微博模型
    var status: Status
    
    /// 行高属性
    lazy var rowHeight: CGFloat = {        
        // 1. 创建cell
        var cell: StatusCell
        
        // 2. 判断是否是转发微博
        if self.status.retweeted_status != nil {
            cell = StatusRetweetedCell(style: .Default, reuseIdentifier: WBHomeRetweetedCellID)
        } else {
            cell = StatusNormalCell(style: .Default, reuseIdentifier: WBHomeNormalCellID)
        }
        
        // 3. 返回行高
        return cell.rowHeight(self)
    }()
    
    /// 可重用 Cell 标示符号
    var cellId: String {
        // 根据是否有转发微博，返回对应的可重用 标示符号
        return status.retweeted_status == nil ? WBHomeNormalCellID : WBHomeRetweetedCellID
    }
    
    /// 微博创建时间
    var createAt: String {
        if let date = NSDate.sinaDate(status.created_at ?? "") {
            return date.dateDescription
        }
        return ""
    }
    
    /// 用户头像 URL
    var userProfileUrl: NSURL {
        return NSURL(string: status.user?.profile_image_url ?? "")!
    }
    /// 认证图像 - 计算型属性，每次调用的时候，都会临时计算！
    /// UIImage(name: XXX) 系统缓存图片，程序员无法释放！
    /// 计算型属性一定要保证执行速度够快，或者有缓存！
    var userVipImage: UIImage? {
        switch status.user?.verified_type ?? -1 {
        case 0: return UIImage(named: "avatar_vip")
        case 2, 3, 5: return UIImage(named: "avatar_enterprise_vip")
        case 220: return UIImage(named: "avatar_grassroot")
        default: return nil
        }
    }
    /// 会员图标
    var userMemberImage: UIImage? {
        if status.user?.mbrank > 0 && status.user?.mbrank < 7 {
            return UIImage(named: "common_icon_membership_level\(status.user!.mbrank)")
        }
        return nil
    }
    
    /// 配图 URL 数组 - 保存住 URL 的数组，不要每次计算(非常重要！)
    /// 如果有转发微博，数组保存的是被转发微博的 pic_urls 对应的图片地址
    /// 如果没有转发微博，数组保存的是原创微博的 pic_urls 对应的图片地址
    var thumbnailUrls: [NSURL]?
    
    /// 被转发微博的原创微博的文字
    var retweetedText: String? {
        let userName = status.retweeted_status?.user?.screen_name ?? ""
        let text = status.retweeted_status?.text ?? ""
        
        return "@" + userName + ":" + text
    }
    
    /// 构造函数
    init(status: Status) {
        self.status = status
        
        // 1> 生成配图 URL 数组
        if let urls = status.retweeted_status?.pic_urls ?? status.pic_urls {
            // 2> 创建缩略图数组
            thumbnailUrls = [NSURL]()
            
            // 3> 遍历数组，添加 URL 数组
            for dict in urls {
                // 之所以强行解包，相信后台程序员
                let url = NSURL(string: dict["thumbnail_pic"] ?? "")
                
                thumbnailUrls?.append(url!)
            }
        }
    }

    /// 描述信息
    var description: String {
        return status.description + " 配图数组 URL + \(thumbnailUrls)"
    }
}
