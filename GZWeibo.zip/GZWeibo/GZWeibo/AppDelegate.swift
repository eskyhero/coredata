//
//  AppDelegate.swift
//  GZWeibo
//
//  Created by Apple on 15/9/21.
//  Copyright © 2015年 itcast. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {

        print(UserAccountViewModel.sharedAccountViewModel.userAccount)
        
        setupAppearance()
        
        window = UIWindow(frame: UIScreen.mainScreen().bounds)
        window?.backgroundColor = UIColor.whiteColor()
        
        // 实例化控制器，完成之后，会调用 viewDidLoad 方法
        window?.rootViewController = defaultRootViewControler()
        
        // 让控制器的根视图可见，就会创建相关的按钮
        window?.makeKeyAndVisible()
        
        // 添加通知
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "switchRootViewController:", name: WBSwitchRootViewControllerNotification, object: nil)
        
        return true
    }
    
    /// 应用程序进入后台
    func applicationDidEnterBackground(application: UIApplication) {
        // 清理数据缓存
        StatusDAL.clearCache()
    }
    
    deinit {
        // 注销通知
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    /// 切换控制器
    @objc private func switchRootViewController(notification: NSNotification) {
        print("切换控制器")
        
        // 判断通知中的对象是否为nil
        let vc = (notification.object != nil) ? WelcomeViewController() : MainViewController()
        
        window?.rootViewController = vc
    }
    
    /// 返回启动默认的控制器 － 多态
    private func defaultRootViewControler() -> UIViewController {
        
        // 1. 判断用户是否登录
        if UserAccountViewModel.sharedAccountViewModel.userLogon {
            // 如果登录，判断是否有新版本
            return isNewVersion() ? NewFeatureViewController() : WelcomeViewController()
        }
        
        // 2. 没有登录，返回主界面
        return MainViewController()
    }
    
    /// 判断是否有新版本
    private func isNewVersion() -> Bool {
        
        // 1. 获取当前的版本
        let currentVersion = NSBundle.mainBundle().infoDictionary!["CFBundleShortVersionString"] as! String
        let version = Double(currentVersion)!
        print(version)
        
        // 2. 获取`之前`的版本 － 将之前的版本保存在沙盒中
        let sandBoxVersionKey = "sandBoxVersionKey"
        // 如果不存在 key，会返回 0.0
        let sandBoxVersion = NSUserDefaults.standardUserDefaults().doubleForKey(sandBoxVersionKey)
        print("当前沙盒版本 - \(sandBoxVersion)")
        
        // 3. 将当前版本保存至沙盒
        NSUserDefaults.standardUserDefaults().setDouble(version, forKey: sandBoxVersionKey)
        
        // 4. 返回两个版本的比较结果
        return version > sandBoxVersion
    }
    
    /// 设置全局外观
    private func setupAppearance() {
        // 全局外观一经设置，全局有效，要尽量早的设置
        // 在商业应用中，全局外观会写在 appDelegate 中
        UINavigationBar.appearance().tintColor = WBAppearanceColor
        UITabBar.appearance().tintColor = WBAppearanceColor
    }
}

